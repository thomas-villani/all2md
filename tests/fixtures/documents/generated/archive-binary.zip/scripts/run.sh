#!/bin/sh
 echo 'ZIP fixture'
