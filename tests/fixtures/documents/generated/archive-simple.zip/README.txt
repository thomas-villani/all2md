Sample ZIP archive for testing
