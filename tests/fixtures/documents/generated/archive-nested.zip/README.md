# Zip Fixture

Contains a nested archive.
